require 'yaml'

module Request
  # Directory
  WEB_ROOT = './public'

  # Content Type Mapping
  CONTENT_TYPE = YAML.load(File.open("./config/content_type.yml").read)
  CONTENT_TYPE_MAPPING = CONTENT_TYPE["MAPPING"]
  DEFAULT_CONTENT_TYPE = CONTENT_TYPE["DEFAULT"]

  def self.content_type(file)
    ext = File.extname(file).split(".").last
    CONTENT_TYPE_MAPPING.fetch(ext, DEFAULT_CONTENT_TYPE)
  end

  def self.method(request_line)
    request_line.split(" ")[0]
  end

  def self.is_file(path)
    File.exist?(path) && !File.directory?(path)
  end

  def self.file_path(request_line)
    request_uri  = request_line.split(" ")[1]
    path = URI.unescape(URI(request_uri).path)

    clean = []
    parts = path.split("/")
    parts.each do |part|
      next if part.empty? || part == "." || path == ".."
      clean << part
    end

    File.directory?(path) ? File.join(clean_path, "index.html") : File.join(WEB_ROOT, *clean)
  end
end
