module Logging
  def self.log(level, message)
    puts "#{level}: #{message}"
  end
end
