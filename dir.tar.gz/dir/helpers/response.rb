module Response
  def self.response_format(code, status, type, size, message="")
    "HTTP/1.1 #{code} #{status}\r\n" +
    "Content-Type: #{type}\r\n" +
    "Content-Length: #{size}\r\n" +
    "Connection: close\r\n" +
    "\r\n" +
    message
  end

  def self.res200(content_type, content_size)
    self.response_format("200", "OK", content_type, content_size)
  end

  def self.res400
    message = "File not found\n"
    self.response_format("404", "Not Found", "text/plain", message.size, message)
  end

  def self.res405
    message = "Method not supported\n"
    self.response_format("405", "Method Not Allowed", "text/plain", message.size, message)
  end

  def self.res500
    message = "Something wrong with the server\n"
    self.response_format("500", "Internal Server Error", "text/plain", message.size, message)
  end
end
