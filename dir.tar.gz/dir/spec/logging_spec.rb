require_relative "../helpers/logging"

RSpec.describe Logging do
  it 'prints error: test' do
    STDOUT.should_receive(:puts).with('error: this is a test')
    Logging.log :error, "this is a test"
  end
end
