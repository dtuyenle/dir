require_relative "../helpers/request"

RSpec.describe Request do
  it 'return method "GET" for "GET /test/test2/test3 HTTP/1.1"' do
    expect(Request.method "GET /test/test2/test3 HTTP/1.1").to eq("GET")
  end

  it 'return method "POST" for "POST /test/test2/test3 HTTP/1.1"' do
    expect(Request.method "POST /test/test2/test3 HTTP/1.1").to eq("POST")
  end

  it 'return content_type "text/html" for html file' do
    File.open("./spec/mocks/test.html", "rb") do |file|
      expect(Request.content_type file).to eq("text/html")
    end
  end

  it 'return false for wrong file path' do
    expect(Request.is_file "./spec/test.html").to eq(false)
  end
end
