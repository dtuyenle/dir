require_relative "../helpers/response"

RSpec.describe Response do
  it 'return 200 payload' do
    payload = "HTTP/1.1 200 OK\r\n" +
    "Content-Type: text/plain\r\n" +
    "Content-Length: 200\r\n" +
    "Connection: close\r\n" +
    "\r\n"
    expect(Response.res200 "text/plain", "200").to eq(payload)
  end

  it 'return 500 payload' do
    payload = "HTTP/1.1 500 Internal Server Error\r\n" +
    "Content-Type: text/plain\r\n" +
    "Content-Length: 32\r\n" +
    "Connection: close\r\n" +
    "\r\n" +
    "Something wrong with the server\n"
    expect(Response.res500).to eq(payload)
  end
end
