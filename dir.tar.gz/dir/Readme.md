Instruction:

Start
+ Run `bundle install`
+ Run `ruby index.rb`
+ Go to http://localhost:2000/index.html

Test
+ Run `rspec`

Note: Serve only static files from public folder and sub folders.

Thoughts:

+ Currently only support absolute path. Could implement RFC Remove Dot Segment but not sure if in scope.

+ If malformed or wrong network request, It will error out and return 500

+ Didn't implement cross domain cause not sure if in scope.

+ Since we strip off all "." and ".." hence directory traversal is mitigated

+ Using multiple threads for concurrent request. In theory we need a thread pool.