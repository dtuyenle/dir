require 'socket'
require 'uri'
require_relative 'helpers/request'
require_relative 'helpers/response'
require_relative 'helpers/logging'

# Start server
server = TCPServer.new('localhost', 2000)
Logging.log :info, "Server listening on port 2000"

loop do
  Thread.start(server.accept) do |socket|
    begin
      # Parse header
      lines = []
      while line = socket.gets and line !~ /^\s*$/
        lines << line.chomp
      end

      # Request first line
      request_line = lines[0]
      Logging.log :access, lines

      # Method
      method = Request.method(request_line)
      case method
      when "GET"
        path = Request.file_path(request_line)
        if Request.is_file(path)
          File.open(path, "rb") do |file|
            socket.print Response.res200(Request.content_type(file), file.size)
            IO.copy_stream(file, socket)
          end
        else
          Logging.log :error, "Not found #{path}"
          socket.print Response.res400
        end
      else
        Logging.log :error, "Method not supported #{method}"
        socket.print Response.res405
      end
    rescue StandardError => e
      Logging.log :error, e.backtrace
      socket.print Response.res500
    end

    socket.close
  end
end
